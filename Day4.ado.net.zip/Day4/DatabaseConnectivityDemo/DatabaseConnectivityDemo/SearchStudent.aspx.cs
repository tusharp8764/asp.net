﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace DatabaseConnectivityDemo
{
    public partial class SearchStudent : System.Web.UI.Page
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["Training"].ConnectionString);
        SqlCommand cmd = null;

        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnSearch_Click(object sender, EventArgs e)
        {
            cmd = new SqlCommand("SELECT * FROM Student_master WHERE Stud_Code = @SCode", con);
            cmd.Parameters.AddWithValue("@SCode", txtCode.Text);

            con.Open();
            SqlDataReader dr = cmd.ExecuteReader();
            if (dr.HasRows)
            {
                dr.Read();
                txtName.Text = dr["Stud_Name"].ToString();
                txtDCode.Text = dr["Dept_Code"].ToString();
                txtDob.Text = dr["Stud_Dob"].ToString();
                txtAddress.Text = dr["Address"].ToString();

                txtName.Enabled = true;
                txtDCode.Enabled = true;
                txtDob.Enabled = true;
                txtAddress.Enabled = true;
                btnUpdate.Enabled = true;
                btnDelete.Enabled = true;
            }
            else
            {
                Response.Write("<SCRIPT type='text/javascript'>alert('Student Data not found for Stud Code "+ txtCode.Text + "');</SCRIPT>");
            }
        }

        protected void btnUpdate_Click(object sender, EventArgs e)
        {
            cmd = new SqlCommand("UPDATE Student_master SET Stud_Name=@SName, Dept_Code=@DCode, Stud_Dob=@DOB, Address=@Address WHERE Stud_Code=@SCode", con);
            cmd.Parameters.AddWithValue("@SName", txtName.Text);
            cmd.Parameters.AddWithValue("@DCode", txtDCode.Text);
            cmd.Parameters.AddWithValue("@DOB", Convert.ToDateTime(txtDob.Text));
            cmd.Parameters.AddWithValue("@Address", txtAddress.Text);
            cmd.Parameters.AddWithValue("@SCode", txtCode.Text);

            con.Open();
            int recordsAffected = cmd.ExecuteNonQuery();
            con.Close();

            if (recordsAffected > 0)
            {
                Response.Write("<SCRIPT type='text/javascript'>alert('Student Data updated for Stud Code " + txtCode.Text + "');</SCRIPT>");
                txtName.Enabled = false;
                txtDCode.Enabled = false;
                txtDob.Enabled = false;
                txtAddress.Enabled = false;
                btnUpdate.Enabled = false;
                btnDelete.Enabled = false;
            }
            else
                Response.Write("<SCRIPT type='text/javascript'>alert('Student Data not updated for Stud Code " + txtCode.Text + "');</SCRIPT>");
        }

        protected void btnDelete_Click(object sender, EventArgs e)
        {
            cmd = new SqlCommand("DELETE FROM Student_master WHERE Stud_Code=@SCode", con);
            cmd.Parameters.AddWithValue("@SCode", txtCode.Text);

            con.Open();
            int recordsAffected = cmd.ExecuteNonQuery();
            con.Close();

            if (recordsAffected > 0)
            {
                Response.Write("<SCRIPT type='text/javascript'>alert('Student Data deleted for Stud Code " + txtCode.Text + "');</SCRIPT>");
                txtName.Enabled = false;
                txtDCode.Enabled = false;
                txtDob.Enabled = false;
                txtAddress.Enabled = false;
                btnUpdate.Enabled = false;
                btnDelete.Enabled = false;
            }
            else
                Response.Write("<SCRIPT type='text/javascript'>alert('Student Data not deleted for Stud Code " + txtCode.Text + "');</SCRIPT>");
        }
    }
}