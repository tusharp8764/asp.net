﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace DropDownDemo
{
    public partial class Student : System.Web.UI.Page
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["Training"].ConnectionString);
            
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                SqlCommand cmd = new SqlCommand("SELECT Stud_Code, Stud_Name FROM Student_master", con);
                con.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                DataTable dt = new DataTable();
                if (dr.HasRows)
                {
                    dt.Load(dr);
                }
                con.Close();

                if (dt.Rows.Count > 0)
                {
                    ddlStudent.DataSource = dt;
                    ddlStudent.DataTextField = "Stud_Name";
                    ddlStudent.DataValueField = "Stud_Code";
                    ddlStudent.DataBind();

                    //foreach (DataRow item in dt.Rows)
                    //{
                    //    ListItem li = new ListItem();
                    //    li.Value = item["Stud_Code"].ToString();
                    //    li.Text = item["Stud_Name"].ToString();
                    //    ddlStudent.Items.Add(li);
                    //}
                }
            } // End of IsPostBack If
        }

        protected void ddlStudent_SelectedIndexChanged(object sender, EventArgs e)
        {
            SqlCommand cmd = new SqlCommand("SELECT * FROM Student_master WHERE Stud_Code = @Stud_Code", con);
            cmd.Parameters.AddWithValue("@Stud_Code", ddlStudent.SelectedValue);
            con.Open();
            SqlDataReader dr = cmd.ExecuteReader();

            DataTable dt = new DataTable();
            if (dr.HasRows)
            {
                dt.Load(dr);
                //dr.Read();
                //var stud = new { StudCode = dr["Stud_Code"], 
                //    StudName = dr["Stud_Name"], 
                //    DeptCode = dr["Dept_Code"], 
                //    DateofBirth = dr["Stud_Dob"], 
                //    Address = dr["Address"] };
            }

            con.Close();

            dvStudent.DataSource = dt;
            dvStudent.DataBind();
        }
    }
}