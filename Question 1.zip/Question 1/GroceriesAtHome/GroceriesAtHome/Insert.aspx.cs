﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace GroceriesAtHome
{
    /// <summary>
    /// Devlopers Name: Tushar Pathak  
    ///Employee ID: 161697
    ///Description: This class contains the connection and insert parameters of Consumer
    ///Created On: November 1st 2018
    /// </summary>


    public partial class Insert : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        protected void btnInsert_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["Training"].ConnectionString);
            SqlCommand cmd = new SqlCommand("insert into Tushar.grocerystore values (@cfirrstName,@clastName,@cgender,@caddress,@caddress,@city,@pincode,@emailid,@contact)", con);
          // cmd.Parameters.AddWithValue("@consumerID", txtID.Text);
            cmd.Parameters.AddWithValue("@cfirrstName", txtfName.Text);
            cmd.Parameters.AddWithValue("@clastName", txtlName.Text);
            cmd.Parameters.AddWithValue("@cgender", Convert.ToChar(txtGender.Text));
            cmd.Parameters.AddWithValue("@caddress", txtAddress.Text);
            cmd.Parameters.AddWithValue("@city", txtCity.Text);
            cmd.Parameters.AddWithValue("@pincode", txtPincode.Text);
            cmd.Parameters.AddWithValue("@emailid", txtEmail.Text);
            cmd.Parameters.AddWithValue("@contact", txtPhone.Text);


           

            con.Open();
            int recordsAffected = cmd.ExecuteNonQuery();
            con.Close();

            if (recordsAffected > 0)
            {
                Response.Write("<SCRIPT type='text/javascript'>alert('Consumer Data inserted successfully');</SCRIPT>");
            }
            else
                Response.Write("<SCRIPT type='text/javascript'>alert('Consumer Data not inserted');</SCRIPT>");

        }

        
    }
}