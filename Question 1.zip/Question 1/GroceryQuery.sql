create table Tushar.grocerystore
(
consumerID int identity(100,1) primary key,
cfirstName varchar(20),
clastName varchar(20),
cgender char,
caddress varchar(50),
city varchar(20),
pincode int,
emailid varchar(20),
contact bigint
)



create proc Tushar.usp_InsertCustomer
@cfirrstName varchar(20),
@clastName varchar(20),
@cgender char,
@caddress varchar(50),
@city varchar(20),
@pincode int,
@emailid varchar(20),
@contact bigint
as
begin
SET IDENTITY_INSERT Tushar.grocerystore ON
insert into Tushar.grocerystore (cfirstName, clastName, cgender,caddress,city,pincode,emailid,contact )
 values (@cfirrstName,@clastName,@cgender,@caddress,@city,@pincode,@emailid,@contact)
end

create proc tushar.usp_DisplayGrocery
as
begin
Select * from Tushar.grocerystore
end
